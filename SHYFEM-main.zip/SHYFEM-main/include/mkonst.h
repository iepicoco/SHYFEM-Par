
	double precision eps1,eps2,pi,flag,high,higi
	common /mkonst/ eps1,eps2,pi,flag,high,higi
	save /mkonst/

