
        integer nvols,kvold,kvolm,kvol(nfxdim)
        common /kvolc/ nvols,kvold,kvolm,kvol
        integer ivolm,ivol(nfxdim)
        common /ivol/ivolm,ivol
	save /kvolc/,/ivol/

