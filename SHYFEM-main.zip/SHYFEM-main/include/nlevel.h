
	integer nlvdi,nlv
	common /level/ nlvdi,nlv
	save /level/

