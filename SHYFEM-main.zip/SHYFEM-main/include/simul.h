
        character*80 descrp
        common /descrp/ descrp
	save /descrp/

