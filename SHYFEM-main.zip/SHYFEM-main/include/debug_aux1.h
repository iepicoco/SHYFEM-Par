
	logical debug
	common /comdebug/ debug
	save /comdebug/

