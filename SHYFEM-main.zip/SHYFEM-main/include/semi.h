
        integer itimpl
        common /semimi/ itimpl
        double precision weight
        common /semimr/ weight

	save /semimi/,/semimr/

