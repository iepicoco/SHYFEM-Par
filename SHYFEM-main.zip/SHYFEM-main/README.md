# Par-SHYFEM
The repository contains the parallel version of the SHYFEM model tailored to the SANIFS_V1 configuration. The parallel implementation is based on a distributed memory approach with MPI.
